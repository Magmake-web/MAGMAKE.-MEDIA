let newsItems=[
  {id:'n1',date:'Oct 7,2025',title:'Community health drive launched',snippet:'Free screenings across the ward.'}
];
function renderNews(){
  const c=document.getElementById('newsContainer');
  c.innerHTML='';
  newsItems.forEach(n=>{
    let el=document.createElement('div');
    el.className='news-item';
    el.innerHTML=`<div class='meta'>${n.date}</div><h4>${n.title}</h4><p>${n.snippet}</p>`;
    c.appendChild(el);
  });
}
renderNews();
function submitComment(blogId){
  const text=document.getElementById('comment-'+blogId).value;
  if(!text)return alert('Write a comment');
  alert('Comment submitted: '+text);
}